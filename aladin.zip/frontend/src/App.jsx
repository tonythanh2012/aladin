
import React from 'react';

function App() {
  return (
    <div>
      <h1>ALADIN MVP</h1>
      <p>Connect wallet, mint NFT, and drag-drop between warehouses coming soon.</p>
    </div>
  );
}

export default App;
